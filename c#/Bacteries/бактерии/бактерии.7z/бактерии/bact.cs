﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace бактерии
{
    public enum BactType
    {
        Piece = 0,
        Evil = 1
    }

    class Bact

    {
        public PointF PosStart, PosFinish, Pos;
        public Bact Target;//бактерия за которой следуют
        public int R = 5;
        public float t; // Время движения от PosStart до PosFinish
        public float v; // скорость
        public bool IsMooving;
        public float AttacDistance;

        public float damage;//урон
        public float VosHeal;//востановление урона при поедании чего-либо

        public int TimeToDie;//время до смерти
        public float Food;//еда
        private float _heal;//здоровье
        public float heal {
            get {
                return _heal;
            }

            set {
                _heal = value;
                IsAlive = _heal > 0;
            }
        }

        public int FoodMax;//еда максимум, рождается ребенок

        public bool thispos;//устраивает ли текущая позиция
        public bool IsAlive = true;
        public BactType type;

        public Bact child;//ребенок-бактерии, зависит от ее текущего состояния
    }
}
